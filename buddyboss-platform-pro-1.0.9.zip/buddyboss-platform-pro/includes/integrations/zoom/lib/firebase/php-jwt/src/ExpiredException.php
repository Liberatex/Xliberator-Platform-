<?php
namespace BuddyBoss\Zoom\Firebase\JWT;

class ExpiredException extends \UnexpectedValueException
{
}
